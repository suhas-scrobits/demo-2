export const IP = "https://www.google.com/api";

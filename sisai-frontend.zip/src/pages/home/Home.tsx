

function Home() {
  return (
    <div>
      Home<br/>
      <a href="/AdminLogin">Admin login flow</a><br/>
      <a href="/UserLogin">User login flow</a>
    </div>
  );
}

export default Home;
